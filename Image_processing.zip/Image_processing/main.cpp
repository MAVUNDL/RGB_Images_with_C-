#include <iostream>
#include "ImagePic.h"

using namespace std;

int main()
{
    // instantiating object
    Image_Type_PPM imageObject(800, 800, {0, 0, 0});

    imageObject.draw_circle(250, {250, 250, 250});
    imageObject.draw_rectangle(300, 50, 250, 50, {200, 200, 200});
    imageObject.draw_rectangle(300, 50, 480, 50, {200, 200, 200});
    imageObject.draw_triangle(380, 400, 30 , {100, 100, 100});
    imageObject.draw_rectangle(460, 50, 350, 100, {200, 200, 200});

    cout << imageObject.toPPM() << endl;
    return 0;
}
