#include "ImagePic.h"

//  default constructor
Image_Type_PPM::Image_Type_PPM() : Image_Type_PPM(rows, cols, {255, 255, 255})
{

}

// parameterised constructor
Image_Type_PPM::Image_Type_PPM(int rows, int columns, Colors colors)
{
    // initialzize pixels
    _pixels = initialize_pixels(rows, columns, colors);
    // setting values
    _rows = rows;
    _cols = columns;
}

// copy constructor
Image_Type_PPM::Image_Type_PPM(const Image_Type_PPM& object)
{
    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            object._pixels[r][c] = _pixels[r][c];
        }
    }
}

// destructor
Image_Type_PPM::~Image_Type_PPM()
{
    for(int r = 0; r < _rows; r++)
        delete _pixels[r];

    delete _pixels;
    _pixels = nullptr;
}

// getters
int Image_Type_PPM::getRows()
{
    return _rows;
}

int Image_Type_PPM::getCols()
{
    return _cols;
}

Colors** Image_Type_PPM::getPixels()
{
    return _pixels;
}

// setters
void Image_Type_PPM::setColor(int row_index, int column_index, Colors color)
{
    if(within_bounds(_rows, _cols, row_index, column_index))
    {
        _pixels[row_index][column_index] = color;
    }
    else
    {
        cerr << "you are out of range: # rows [ " << 0  << " - " << _rows << " ] & # columns  [ " << 0  << " - " << _cols << " ] " << endl;
        exit(-2);
    }
}

//Methods
bool Image_Type_PPM::within_bounds(int rows, int columns, int row_index, int column_index)
{
    return (row_index >= 0 && row_index < rows && column_index >= 0 && column_index < columns);
}

Colors** Image_Type_PPM::initialize_pixels(int rows, int columns, Colors colors)
{
    Colors** pixels;

    pixels = new Colors*[rows];

    for(int r = 0; r < rows; r++)
    {
        pixels[r] =  new Colors[columns];

        for(int c = 0; c < columns; c++)
        {
            pixels[r][c] = colors;
        }
    }

    return pixels;
}

string Image_Type_PPM::toPPM()
{
    stringstream toPPM;

    toPPM << "P3" <<endl;
    toPPM << _cols << " " << _rows << endl;
    toPPM << 255 << endl;

    for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            toPPM << _pixels[r][c]._Red << " "
                  << _pixels[r][c]._Green << " "
                  << _pixels[r][c]._Blue << " ";
        }
        toPPM << endl;
    }

    return toPPM.str();
}

void Image_Type_PPM::draw_circle(int radius, Colors color)
{
    // looping to draw the circle
     for(int r = 0; r < _rows; r++)
    {
        for(int c = 0; c < _cols; c++)
        {
            // get x coordinates
            int _x_ = r - (_rows / 2);
            // get y coordinates
            int _y_ = c - (_cols / 2);
            // use the equation of a circle to draw the circle
            if (_x_ * _x_ + _y_ * _y_ <= radius * radius)
            {
                _pixels[r][c] = color;
            }
        }
    }
}

void Image_Type_PPM::draw_rectangle(int x_coord, int length, int y_coord, int breadth, Colors color)
{
    if(within_bounds(_rows, _cols, x_coord + length, y_coord + breadth))
    {
       for(int r = x_coord; r < x_coord + length; r++)
       {
           for( int c = y_coord; c < y_coord + breadth; c++)
           {
               _pixels[r][c] = color;
           }
       }
    }
}

void Image_Type_PPM::draw_triangle(int x, int y, int side_length, Colors color)
{
    if (within_bounds(_rows, _cols, x, y))
    {
        for (int r = 0; r < side_length; r++)
        {
            for (int c = 0; c <= r; c++)
            {
                // Check and set the pixel within bounds for each side
                if (within_bounds(_rows, _cols, x + r, y + c))
                {
                    _pixels[x + r][y + c] = color; // Right edge
                }
                if (within_bounds(_rows, _cols, x + r, y - c))
                {
                    _pixels[x + r][y - c] = color; // Left edge
                }
            }
        }
    }
}






