#ifndef IMAGEPIC_H_INCLUDED
#define IMAGEPIC_H_INCLUDED

#include <iostream>
#include <sstream>
#include <cstdlib>

using namespace std;

// record structure for pixels
struct Colors
{
    int _Red;
    int _Green;
    int _Blue;
};

class Image_Type_PPM
{
    private:
        // image dimensions
        int _rows;
        int _cols;
        // pixels
        Colors** _pixels;

    public:
        //  default constructor
        Image_Type_PPM();
        // parameterised constructor
        Image_Type_PPM(int rows, int columns, Colors colors);
        // copy constructor
        Image_Type_PPM(const Image_Type_PPM& object);
        // destructor
        ~Image_Type_PPM();

        // getters
        int getRows();
        int getCols();
        Colors** getPixels();

        // setters
        void setColor(int row_index, int column_index, Colors color);

        //Methods
        bool within_bounds(int rows, int columns, int row_index, int column_index);
        Colors** initialize_pixels(int rows, int columns, Colors colors);
        void draw_circle(int radius, Colors color);
        string toPPM();
        void draw_rectangle(int x_coord, int length, int y_coord, int breadth, Colors color);
        void draw_triangle(int x, int y, int side_length, Colors color);

        // default values
        static const int rows = 15;
        static const int cols = 15;


};


#endif // IMAGEPIC_H_INCLUDED
